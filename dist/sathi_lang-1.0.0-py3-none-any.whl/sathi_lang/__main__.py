#!/usr/bin/env python3
import sys, re

variables = {}

def eval_expr(expr):
    """Evaluate Python-like expressions inside Sathi."""
    try:
        return eval(expr, {}, variables)
    except Exception:
        return expr.strip('"')

def run_sathi(code):
    """Interpret and execute Sathi source code."""
    lines = code.splitlines()
    for line in lines:
        line = line.strip()
        if not line or not line.startswith("sathi"):
            continue

        # Print statement
        if "bhanna" in line:
            msg = line.split("bhanna", 1)[1].strip()
            print(eval_expr(msg))
        
        # Variable declaration
        elif "yo ho" in line:
            match = re.match(r"sathi yo ho (\w+)\s*=\s*(.+)", line)
            if match:
                var, val = match.groups()
                variables[var] = eval_expr(val)

def main():
    if len(sys.argv) < 2:
        print("Usage: sathi <file.sathi>")
        sys.exit(1)

    filename = sys.argv[1]
    try:
        with open(filename, "r", encoding="utf-8") as f:
            code = f.read()
        run_sathi(code)
    except FileNotFoundError:
        print(f"Error: file '{filename}' not found.")
    except Exception as e:
        print("Sathi Error:", e)

if __name__ == "__main__":
    main()
